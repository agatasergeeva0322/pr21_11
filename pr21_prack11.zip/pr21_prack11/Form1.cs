﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr21_prack11
{
    public partial class Student_work :Form
    {
        public Student_work ()
        {
            InitializeComponent();
        }

        public class Student
        {
            public string name;
            public double rost;
            private double ves = 40;
            public double GetEat ()
            {
                return ves;
            }
            public double SetEat (int eda)
            {
                ves = ves + eda - 2800 / 1000;
                return ves;
            }
        }
        private void button1_Click (object sender, EventArgs e)
        {
            Student student1 = new Student();
            student1.name = textBox2.Text;
            student1.rost = (double) (numericUpDown2.Value);
            MessageBox.Show(string.Format("Студент:{0}\nРост:{1}\nВес:{2}", student1.name, student1.rost, student1.GetEat()));
        }
    }
}
