﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr21_prack11
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main ()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Student_work());

        }

        public class Student
        {
            public string name;
            public double rost;
            private double ves = 40;
            public double GetEat ()
            {
                return ves;
            }
            public double SetEat (int eda)
            {
                ves = ves + eda - 2800 / 1000;
                return ves;
            }
        }

    }   
}
