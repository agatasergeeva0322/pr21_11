﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class Student
        {
            public string name;
            public double rost;
            public double rostposle;
            public double vesposle;
            public double do_;
            public double GetEat()
            {
                return do_;
            }
            public double SetEat(double eda, double vesposle)
            {
                if (eda >= 5 && eda <= 10)
                {
                    vesposle = do_ + eda - 2800 / 1000;
                }
                else if (eda > 10) vesposle = do_ + eda - 3000 / 1000;
                return vesposle;
            }
            public double RostSetEat(double eda, double rost)
            {
                if (eda >= 5 && eda <= 10)
                {
                    rost = rost - 1;
                }
                else if (eda > 10) rost = rost - 2;
                return rost;
            }

        }
            
            private void button1_Click(object sender, EventArgs e)
        {
            Student student1 = new Student();
            double eda = (int)(numericUpDown3.Value);
            student1.name = textBox1.Text;
            student1.rost = (double)(numericUpDown1.Value);
            student1.do_ = (double)(numericUpDown4.Value);
            double before = student1.do_;
            student1.vesposle = student1.SetEat(eda, student1.do_);
            double after = student1.vesposle;
            student1.rostposle = student1.RostSetEat(eda, student1.rost);
            double rostafter = student1.rostposle;
            MessageBox.Show(string.Format($"Студент: {student1.name}\nРост: {student1.rost} см.\nВес: {before} кг.\nСъел(а): {eda} кг.\n\n\nРост после еды: {rostafter} см. \nВес после еды: {after} кг."));
        }
    }
}
